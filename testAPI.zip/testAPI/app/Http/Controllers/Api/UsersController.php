<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Usernew;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class UsersController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $users = DB::table('users')->get();
        foreach ($users as $user) {
            // echo $user->title;
            $isi[] = array(
                'name'     => $user->name,
                'username' => $user->username,
                'password' => $user->password
            );

        }
       /* $result= array(
            'status'=>'true',
            'data'=>$isi
        );
        return json_encode($result);*/
        if ($users->isEmpty()) {

            return response()->json([
                    'status'  => true,
                    'message' => "belum ada data",
                    'data'    => ""
            ]);

        } else {

            return response()->json([
                    'status' => true,
                    // 'data'   => $isi[0]['username']
                    'data'=>$users
            ]);
        }
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $metod    = $request->input('metod');
        $name     = $request->input('name');
        $username = $request->input('username');
        $password = $request->input('password');


        if ($metod=="register") {

            if ($name=="" || $username=="" || $password=="") {

                return response()->json([
                    'status'  => false,
                    'message' => "Incorrect data",
                    'data'    => ""
                ]);

            } else {

                $result = DB::insert('insert into users (name, username, password) values (?,?,?)', 
                                    [$name, $username,$password]);

                if ($result) {

                    return response()->json([
                        'status'  => true,
                        'message' => "Register successfully!",
                        'data'    => $result
                    ]);

                } else {

                    return response()->json([
                        'status'  => false,
                        'message' => "Register Failed!!! Something Wrong",
                        'data'    => ""
                    ]);
                }

            }

        } else  if ($metod=="login") {

            if ($username=="" || $password=="") {

                return response()->json([
                    'status'  => false,
                    'message' => "Please fill complete your data",
                    'data'    => ""
                ]);

            } else {

                if (DB::table('users')
                    ->where('username', $username)
                    ->where('password', $password)
                    ->exists()) 
                {
                    return response()->json([
                        'status'  => true,
                        'message' => "Successfully!!!",
                        'data'    => "Yeess, you can login"
                    ]);       

                } else {

                    return response()->json([
                        'status'  => false,
                        'message' => "Sorry, check your data again or register first please",
                        'data'    => ""
                    ]);
                }
            }

        }
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Usernew  $usernew
     * @return \Illuminate\Http\Response
     */
    public function show(Usernew $usernew)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Usernew  $usernew
     * @return \Illuminate\Http\Response
     */
    public function edit(Usernew $usernew)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Usernew  $usernew
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Usernew $usernew)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Usernew  $usernew
     * @return \Illuminate\Http\Response
     */
    public function destroy(Usernew $usernew)
    {
        //
    }
}
