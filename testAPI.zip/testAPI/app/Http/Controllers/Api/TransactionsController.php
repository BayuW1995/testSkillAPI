<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Transactions;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class TransactionsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $users = DB::table('transactions')->get();
        foreach ($users as $user) {
            // echo $user->title;
            $isi[] = array(
                'status'            => $user->status,
                'reference_number'  => $user->reference_number,
                'quantity'          => $user->quantity,
                'price'             => $user->price,
                'total_price'       => $user->total_price,
                'user_id'           => $user->user_id,
                'product_id'        => $user->product_id

            );

        }
       /* $result= array(
            'status'=>'true',
            'data'=>$isi
        );
        return json_encode($result);*/
        if ($users->isEmpty()) {

            return response()->json([
                    'status'  => true,
                    'message' => "belum ada data",
                    'data'    => ""
            ]);

        } else {

            return response()->json([
                    'status' => true,
                    'data'   => $users
            ]);
        }
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $username           = $request->input('username');
        $password           = $request->input('password');
        $reference_number   = $request->input('reference_number');
        $quantity           = $request->input('quantity');
        $price              = $request->input('price');
        
        $users = DB::table('users')
                ->where('username', $username)
                ->where('password',$password)
                ->get();

        if ($users->isEmpty()) {

            return response()->json([
                    'status'        => 401,
                    'response code' => 4019900,
                    'message'       => "Unauthorized (Invalid API Key)",
                    'data'          => ""
            ]);

        } else {

                if ($reference_number=="" || $quantity=="" || $price=="") {

                    return response()->json([
                        'status'        => 400,
                        'response code' => 4009901,
                        'message'       => "Invalid Field Format (Field)",
                        'data'          => ""
                    ]);

                } else {

                    foreach ($users as $user) {
                            // echo $user->title;
                            $isi[] = array(
                                'user_id'     => $user->id,
                            );

                    $user_id     = $isi[0]['user_id'];
                    $product_id  = 1;
                    $total_price = $quantity * $price;

                    $result = DB::insert('insert into transactions (reference_number, quantity, price,
                                         total_price,user_id,product_id) values (?,?,?,?,?,?)',
                              [$reference_number, $quantity, $price, $total_price,$user_id,$product_id]);

                    if ($result) {

                        return response()->json([
                            'status'        => 200,
                            'response code' => 2009900,
                            'message'       => "Successful",
                            'data'          => $result
                        ]);

                    } else {

                        return response()->json([
                            'status'        => 500,
                            'response code' => 5009901,
                            'message'       => "Internal Server Error",
                            'data'          => ""
                        ]);
                    }

                }
            }

        }
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Transactions  $transactions
     * @return \Illuminate\Http\Response
     */
    public function show(Transactions $transactions)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Transactions  $transactions
     * @return \Illuminate\Http\Response
     */
    public function edit(Transactions $transactions)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Transactions  $transactions
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Transactions $transactions)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Transactions  $transactions
     * @return \Illuminate\Http\Response
     */
    public function destroy(Transactions $transactions)
    {
        //
    }
}
