<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Product;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class ProductsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $users = DB::table('products')->get();
        foreach ($users as $user) {
            // echo $user->title;
            $isi[] = array(
                'name'  => $user->name,
                'price' => $user->price,
                'stock' => $user->stock
            );

        }
       /* $result= array(
            'status'=>'true',
            'data'=>$isi
        );
        return json_encode($result);*/
        if ($users->isEmpty()) {

            return response()->json([
                    'status'  => true,
                    'message' => "belum ada data",
                    'data'    => ""
            ]);

        } else {

            return response()->json([
                    'status' => true,
                    'data'   => $users
            ]);
        }
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $id    = $request->input('id');
        $name  = $request->input('name');
        $price = $request->input('price');
        $stock = $request->input('stock');

        if ($id=="") {
            
            if ($name=="" || $price=="" || $stock=="") {

                return response()->json([
                    'status'  => false,
                    'message' => "Incorrect data",
                    'data'    => ""
                ]);

            } else {

                $result = DB::insert('insert into products (name, price, stock) values (?,?,?)', 
                                    [$name, $price,$stock]);

                if ($result) {

                    return response()->json([
                        'status'  => true,
                        'message' => "Insert new data successfully!",
                        'data'    => $result
                    ]);

                } else {

                    return response()->json([
                        'status'  => false,
                        'message' => "Insert new data Failed!!! Something Wrong",
                        'data'    => ""
                    ]);
                }

            }

        } else {

            if ($name=="" || $price=="" || $stock=="") {

                return response()->json([
                    'status'  => false,
                    'message' => "Incorrect data",
                    'data'    => ""
                ]);

            } else {

                $result = DB::table('products')
                          ->where('id', $id)
                          ->update ([
                                    'name'  => $name,
                                    'price' => $price,
                                    'stock' => $stock
                                   ]);

                if ($result==1) {

                    return response()->json([
                        'status'  => true,
                        'message' => "Update data successfully!",
                        'data'    => $result
                    ]);

                } elseif ($result==0) {
                    
                    return response()->json([
                        'status'  => false,
                        'message' => "Nothing data change, check your data again",
                        'data'    => ""
                    ]);

                } else {

                    return response()->json([
                        'status'  => false,
                        'message' => "Update data Failed!!! Something Wrong",
                        'data'    => ""
                    ]);
                }

            }

        }
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Product  $product
     * @return \Illuminate\Http\Response
     */
    public function show(Product $product)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Product  $product
     * @return \Illuminate\Http\Response
     */
    public function edit(Product $product)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Product  $product
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Product $product)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Product  $product
     * @return \Illuminate\Http\Response
     */
    public function destroy(Product $product)
    {
        //
    }
}
